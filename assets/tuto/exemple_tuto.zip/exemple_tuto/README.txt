### exemple dataset for SLIM ###

This archive contains two folders and a file:
input files/
results/
pipeline.conf

The "input files" folder contains the input files of the tutorial. Such files includes two fastq 
files (R1 and R2 of an illumina library), a reference sequence database (here PR2), a fasta
containing the names and sequences of the tagged primers used to multiplex the library, 
and a tag-to-sample table that make the correspondance between tagged primers combinations 
the samples names. 

The "results" folder contains the resulting annotated OTU table as well as the OTU representative 
sequences obtained with this dataset and configuration.


### running the tutorial ###

1. Navigate with your internet browser to your SLIM interface (see https://github.com/yoann-dufresne/SLIM#accessing-the-webserver)

2. Click on "choose files" and navigate to the input files folder. Then select all the files 
inside the "input files" folder and click on upload. 

3. Click on "load" in the configuration section and select the "pipeline.conf". 

You can then enter your email and hit the "start analysis" button. 

