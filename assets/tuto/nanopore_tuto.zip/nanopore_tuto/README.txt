### exemple dataset for SLIM ###

This archive contains two folders and a file:
input files/
results/
pipeline.conf

The "input files" folder contains the input files of the tutorial. Such files includes fastq 
files generated from an oxford nanopore minion, a reference sequence database (here PR2), a fasta
containing the names and sequences of the PCR primers (foward has to come first). 

The "results" folder contains the resulting annotated OTU table as well as the OTU representative 
sequences obtained with this dataset and configuration.


### running the tutorial ###

1. Navigate with your internet browser to your SLIM interface (see https://github.com/trtcrd/SLIM#accessing-the-webserver)

2. Click on "choose files" and navigate to the input files folder. Then select all the files 
inside the "input files" folder and click on upload. 

3. Click on "load" in the configuration section and select the "pipeline.conf". 

You can then enter your email and hit the "start analysis" button. 

